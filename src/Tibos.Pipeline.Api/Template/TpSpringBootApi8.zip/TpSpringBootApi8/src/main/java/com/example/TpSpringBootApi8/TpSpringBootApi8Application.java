package com.example.TpSpringBootApi8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpSpringBootApi8Application {

	public static void main(String[] args) {
		SpringApplication.run(TpSpringBootApi8Application.class, args);
	}

}
