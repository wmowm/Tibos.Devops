package com.example.TpSpringBootApi8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringBootApi8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
